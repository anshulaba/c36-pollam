var canvas,database,gameState=0,playerCount;
var form,game,player;

function setup()
{
  canvas=createCanvas(400,400);
  database=firebase.database();


}

function draw()
{

}